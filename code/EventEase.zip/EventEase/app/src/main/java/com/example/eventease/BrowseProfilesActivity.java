package com.example.eventease;

public class BrowseProfilesActivity {
}
